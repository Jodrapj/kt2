import java.util.*

fun main(args: Array<String>) {

    //задание 1
    //val amount= 100000.0
    //val p= 0.75;
    //val otv: Double;
    //if (amount * p / 100 >= 35)
    //    otv = amount - (amount * p / 100);
    //else
    //    otv = amount - 35;
    //print(otv)

    //задание 2
    //val scanner = Scanner(System.`in`)
    //println("Сколько лайков?")
    //val likes = scanner.nextInt()
    //if (likes % 2 == 1)
    //    println("Понравилось " + likes + " человеку")
    //if (likes % 2 == 0)
    //    println("Понравилось " + likes + " людям")

    //задание 3
    //val scanner = Scanner(System.`in`)
    //println("Какая сумма покупки?")
    //val sum = scanner.nextInt()
    //if ((0 < sum) && (sum < 1000))
    //    println("Скидка не предоставляется")
    //if ((1001 < sum) && (sum < 10_000))
    //    println("Скидка составляет 100 рублей")
    //if (10_001 < sum)
    //    println("Скидка составляет 5% от суммы")
}